<?php
/**
 * Created by PhpStorm.
 * User: intern
 * Date: 2017/11/29
 * Time: 上午10:15
 */
return [
    'sign_config_type' => 'pinjie', //加密字符串的拼接
    'sign_time' => 120,//sign请求响应时间
    'cache_time' => 180 //sign缓存的时间
];