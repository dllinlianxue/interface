<?php
/**
 * Created by PhpStorm.
 * User: intern
 * Date: 2017/11/29
 * Time: 上午9:13
 */
return [
  'default_return_type' => 'json'
];